"use client";
import {useState} from "react";

export default function Home(){
  const [script,setScript]=useState("");
  const [duration,setDuration]=useState("5");
  const [ratio,setRatio]=useState("9:16");
  const [language,setLanguage]=useState("Hindi");
  const [style,setStyle]=useState("Cinematic");
  const [status,setStatus]=useState("");

  function generate(){
    if(!script.trim()){setStatus("पहले अपनी कहानी/स्क्रिप्ट लिखें।");return;}
    setStatus("Demo mode: script received. अब backend में AI video API जोड़ना बाकी है।");
  }

  return <main style={{maxWidth:900,margin:"0 auto",padding:"40px 18px"}}>
    <div style={{textAlign:"center",marginBottom:30}}>
      <div style={{fontSize:42}}>🎬</div>
      <h1 style={{fontSize:36,margin:"8px 0"}}>AI Video Maker</h1>
      <p style={{color:"#667085",fontSize:17}}>Script डालें और 5 मिनट की AI वीडियो तैयार करें</p>
    </div>

    <section style={card}>
      <label style={label}>अपनी कहानी / Script</label>
      <textarea value={script} onChange={e=>setScript(e.target.value)}
        placeholder="उदाहरण: भगवान कृष्ण की 5 मिनट की प्रेरणादायक कहानी..."
        style={{...input,minHeight:190,resize:"vertical"}} />

      <div style={grid}>
        <Field title="Duration">
          <select value={duration} onChange={e=>setDuration(e.target.value)} style={input}>
            <option value="1">1 मिनट</option><option value="3">3 मिनट</option><option value="5">5 मिनट</option>
          </select>
        </Field>
        <Field title="Format">
          <select value={ratio} onChange={e=>setRatio(e.target.value)} style={input}>
            <option>9:16</option><option>16:9</option><option>1:1</option>
          </select>
        </Field>
        <Field title="Language">
          <select value={language} onChange={e=>setLanguage(e.target.value)} style={input}>
            <option>Hindi</option><option>English</option><option>Bhojpuri</option><option>Maithili</option>
          </select>
        </Field>
        <Field title="Visual Style">
          <select value={style} onChange={e=>setStyle(e.target.value)} style={input}>
            <option>Cinematic</option><option>3D Animation</option><option>Realistic</option><option>Cartoon</option><option>Mythology</option>
          </select>
        </Field>
      </div>

      <button onClick={generate} style={button}>🚀 Generate Video</button>
      {status && <div style={notice}>{status}</div>}
    </section>

    <section style={{...card,marginTop:20}}>
      <h2 style={{marginTop:0}}>⚙️ Production Pipeline</h2>
      <div style={steps}>
        {["Script → Scenes","AI Visuals","Hindi Voice","Music + SFX","Video Rendering","MP4 Export"].map((x,i)=>
          <div key={x} style={step}><b>{i+1}</b><span>{x}</span></div>)}
      </div>
      <p style={{color:"#667085",marginBottom:0}}>नोट: यह starter UI है। वास्तविक AI generation के लिए server-side API integration जोड़ना होगा; API keys browser में नहीं रखें।</p>
    </section>
  </main>
}

function Field({title,children}){return <div><label style={label}>{title}</label>{children}</div>}
const card={background:"#fff",borderRadius:18,padding:24,boxShadow:"0 8px 30px rgba(0,0,0,.06)"};
const label={display:"block",fontWeight:700,marginBottom:8};
const input={width:"100%",boxSizing:"border-box",padding:"13px 14px",border:"1px solid #d0d5dd",borderRadius:10,fontSize:15,background:"#fff"};
const grid={display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(180px,1fr))",gap:16,marginTop:20};
const button={width:"100%",marginTop:22,padding:15,border:0,borderRadius:12,background:"#111827",color:"#fff",fontSize:17,fontWeight:700,cursor:"pointer"};
const notice={marginTop:16,padding:13,borderRadius:10,background:"#f2f4f7",color:"#344054"};
const steps={display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:12};
const step={padding:14,border:"1px solid #eaecf0",borderRadius:12,display:"flex",gap:10,alignItems:"center"};
