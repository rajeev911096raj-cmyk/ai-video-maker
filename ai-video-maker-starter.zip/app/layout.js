export const metadata = { title: "AI Video Maker", description: "Create long AI videos from a script." };
export default function RootLayout({children}) {
  return <html lang="hi"><body style={{margin:0,fontFamily:"Arial, sans-serif",background:"#f6f7fb"}}>{children}</body></html>;
}